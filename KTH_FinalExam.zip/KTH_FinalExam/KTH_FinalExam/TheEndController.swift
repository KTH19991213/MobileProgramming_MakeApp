//
//  TheEndController.swift
//  KTH_FinalExam
//
//  Created by 203a26 on 2022/06/15.
//

import UIKit

class TheEndController: UIViewController {
    @IBOutlet var Resetbtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func GoResetbtn(_ sender: Any) {
        let myStoryBoard = self.storyboard?.instantiateViewController(withIdentifier: "myStoryBoard")
                myStoryBoard?.modalPresentationStyle = .fullScreen //전체화면으로 보이게 설정
                myStoryBoard?.modalTransitionStyle = .crossDissolve //전환 애니메이션 설정
                self.present(myStoryBoard!, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
