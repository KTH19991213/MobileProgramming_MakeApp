//
//  ViewController.swift
//  KTH_FinalExam
//
//  Created by 203a26 on 2022/06/15.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var EnterQuizbtn: UIButton!
    @IBOutlet var Fakebtn: UIButton!
    
    
    let myStoryBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   
    @IBAction func onClick_Enter(_ sender: Any) {
    
    //퀴즈입장
   //     let QuizController = myStoryBoard.instantiateViewController(withIdentifier: "QuizController")
        
  //      self.show(QuizController, sender: self)
        
        let QuizBoard = self.storyboard?.instantiateViewController(withIdentifier: "QuizBoard")
                QuizBoard?.modalPresentationStyle = .fullScreen //전체화면으로 보이게 설정
                QuizBoard?.modalTransitionStyle = .crossDissolve //전환 애니메이션 설정
                self.present(QuizBoard!, animated: true, completion: nil)
    }
    
    @IBAction func onClick_Fake(_ sender: Any) {
        
        let FakeBoard = myStoryBoard.instantiateViewController(withIdentifier: "FakeBoard")
        self.show(FakeBoard, sender: self)
    }
    
}

