//
//  QuizController.swift
//  KTH_FinalExam
//
//  Created by 203a26 on 2022/06/15.
//

import UIKit

class QuizController: UIViewController {
    @IBOutlet var Truebtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClick_btn(_ sender: Any) {
        
        let QuizFinalBoard = self.storyboard?.instantiateViewController(withIdentifier: "QuizFinalBoard")
                QuizFinalBoard?.modalPresentationStyle = .fullScreen //전체화면으로 보이게 설정
                QuizFinalBoard?.modalTransitionStyle = .crossDissolve //전환 애니메이션 설정
                self.present(QuizFinalBoard!, animated: true, completion: nil)
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
